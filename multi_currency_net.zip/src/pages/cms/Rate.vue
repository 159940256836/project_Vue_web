<template>
    <div class="rate">
        <div class="content-wrap">
            <div class="ww">
                <div class="container" id="List">
                    <div class="rate-content">
                        <h2>久财网全球专业站 法币交易平台服务费率说明</h2>
                        <div class="rate-in">
                            <h3>费率说明：</h3>
                            <p>1、注册、购买和出售数字资产完全免费。</p>
                            <p>2、创建交易广告的用户每笔完成的交易需要缴纳 1% 的费用。</p>
                            <p>3、平台不收取用户的提币费用，但需自行支付网络手续费。</p>
                            <p class="shows"> 温馨提示：上线首月（11月4日-12月31日），交易手续费全免！</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<style scoped>
.rate {
    background-color: #f7f7fa;
}
.rate-content{
    min-height: 520px;
}
.rate .rate-content {
    padding-top: 20px;
}
.rate .rate-content h2 {
    text-align: center;
    font-size: 24px;
    font-weight: 100;
    margin: 10px 0;
}
.rate .rate-content h3 {
    font-size: 24px;
    font-weight: normal;
    margin: 10px 0;
}
.rate .rate-content p {
    font-size: 16px;
}
.rate .rate-content .shows {
    color: red;
    margin-top: 30px;
}

</style>
